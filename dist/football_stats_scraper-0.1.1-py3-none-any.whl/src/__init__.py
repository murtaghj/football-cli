from .enums import Leagues, ReturnFormats
from .defines import interesting_league_table_columns, table_base_url
