table_base_url = 'https://www.theguardian.com/football/{league_value}/table'.format
fixtures_base_url = 'https://www.theguardian.com/football/{league_value}/fixtures'.format
interesting_league_table_columns = ['P', 'Team', 'GP', 'W', 'L', 'F', 'A', 'GD', 'Pts']
interesting_fixture_columns = ['Match status / kick off time', 'Unnamed: 2']
